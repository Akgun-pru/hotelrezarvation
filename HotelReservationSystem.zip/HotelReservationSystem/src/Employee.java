public class Employee extends Person implements IEmployee {
    private double wage;
    private String department;

    public Employee(String name, String surname, int age) {
        super(name, surname, age);
    }

    public Employee(String name, String surname, int age, double wage, String department) {
        super(name, surname, age);
        this.wage = wage;
        this.department = department;
    }

    @Override
    public double getWage() {
        return wage;
    }

    @Override
    public void setWage(double wage) {
        this.wage = wage;
    }

    @Override
    public String getDepartment() {
        return department;
    }

    @Override
    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "wage=" + wage +
                ", department='" + department + '\'' +
                "} " + super.toString();
    }
}
