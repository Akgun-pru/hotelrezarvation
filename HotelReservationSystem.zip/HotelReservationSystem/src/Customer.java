public class Customer extends Person implements ICustomer {
    private String phoneNumber;
    private String HesCode;

    public Customer(String name, String surname, int age) {
        super(name, surname, age);
    }

    public Customer(String name, String surname, int age, String phoneNumber, String hesCode) {
        super(name, surname, age);
        this.phoneNumber = phoneNumber;
        HesCode = hesCode;
    }

    @Override
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public String getHesCode() {
        return HesCode;
    }

    @Override
    public void setHesCode(String hesCode) {
        HesCode = hesCode;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "phoneNumber='" + phoneNumber + '\'' +
                ", HesCode='" + HesCode + '\'' +
                "} " + super.toString();
    }
}
