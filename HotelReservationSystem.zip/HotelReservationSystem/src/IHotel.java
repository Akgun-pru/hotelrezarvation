import java.util.ArrayList;

public interface IHotel {
    ArrayList<Room> getRooms();

    void setRooms(ArrayList<Room> rooms);

    boolean RentRoom(Customer customer, Room room);

    @Override
    String toString();

	ArrayList<Customer> getCustomers();

	void setCustomers(ArrayList<Customer> customers);
}
