public interface ICustomer extends IPerson {
    String getPhoneNumber();

    void setPhoneNumber(String phoneNumber);

    String getHesCode();

    void setHesCode(String hesCode);

    @Override
    String toString();
}
