public interface IPerson {
    String getName();

    void setName(String name);

    String getSurname();

    void setSurname(String surname);

    int getAge();

    void setAge(int age);

    @Override
    String toString();
}
