import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainWindow {

	private JFrame frmHotelReservationSystem;
	private JTable tableRooms;
	private JTable tableCustomers;
	JComboBox customerCb,roomsCb;
	Hotel hotel = new Hotel(new ArrayList<Room>());
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow window = new MainWindow();
					window.frmHotelReservationSystem.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MainWindow() {
		initialize();
	}
	public void showCustomers() {
		DefaultTableModel dft = new DefaultTableModel();
		dft.addColumn("Customer");
		for(Customer c:hotel.getCustomers()) {
			dft.addRow(new String[] {c.toString()});
		}
		tableCustomers.setModel(dft);
	}
	public void showRooms() {
			DefaultTableModel dft = new DefaultTableModel();
			dft.addColumn("Room");
			for(Room c:hotel.getRooms()) {
				dft.addRow(new String[] {c.toString()});
			}
			tableRooms.setModel(dft);
	}
	public void listCustomers() {
		customerCb.removeAll();
		for(Customer c:hotel.getCustomers()) {
			customerCb.addItem(c.getName()+" "+c.getSurname());
		}
	}
	public void listRooms() {
		roomsCb.removeAll();
		for(Room c:hotel.getRooms()) {
			roomsCb.addItem(c.getId());
		}
	}
	private void initialize() {
		frmHotelReservationSystem = new JFrame();
		frmHotelReservationSystem.setTitle("Hotel Reservation System");
		frmHotelReservationSystem.setBounds(100, 100, 902, 340);
		frmHotelReservationSystem.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmHotelReservationSystem.getContentPane().setLayout(null);
		
		 roomsCb = new JComboBox();
		roomsCb.setBounds(161, 11, 182, 20);
		frmHotelReservationSystem.getContentPane().add(roomsCb);
		
		JLabel lblSelectRoom = new JLabel("Select Room:");
		lblSelectRoom.setBounds(10, 14, 141, 14);
		frmHotelReservationSystem.getContentPane().add(lblSelectRoom);
		
		JButton btnRent = new JButton("Rent/Add To Room");
		btnRent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(customerCb.getSelectedIndex()>=0&&roomsCb.getSelectedIndex()>=0) {
					Customer c = FindCustomer(customerCb.getSelectedItem().toString());
					Room r = FindRoom(roomsCb.getSelectedItem().toString());
					if(c!=null&&r!=null) {
						if(r.IsEmpty()) {
							if(hotel.RentRoom(c, r)) {
								JOptionPane.showMessageDialog(null, "Room rented!");
								listRooms();
								listCustomers();
								showRooms();
								showCustomers();
							}
						}
						else {
							JOptionPane.showMessageDialog(null, "This room is already rented");
						}
					}
				}
				else {
					JOptionPane.showMessageDialog(null,"Please select a room and customer");
				}
			}

			private Customer FindCustomer(String string) {
				for(Customer c:hotel.getCustomers()) {
					if(((c.getName()+" "+c.getSurname()).equals(string))) {
						return c;
					}
				}
				return null;
			}

			private Room FindRoom(String string) {
				for(Room r:hotel.getRooms()) {
					if(r.getId().equals(string)) {
						return r;
					}
				}
				return null;
			}
		});
		btnRent.setBounds(161, 67, 182, 23);
		frmHotelReservationSystem.getContentPane().add(btnRent);
		
		JLabel lblSelectCustomer = new JLabel("Select Customer:");
		lblSelectCustomer.setBounds(10, 39, 141, 14);
		frmHotelReservationSystem.getContentPane().add(lblSelectCustomer);
		
		 customerCb = new JComboBox();
		customerCb.setBounds(161, 36, 182, 20);
		frmHotelReservationSystem.getContentPane().add(customerCb);
		
		JLabel lblLogged = new JLabel("Logged As:");
		lblLogged.setBounds(367, 14, 509, 14);
		frmHotelReservationSystem.getContentPane().add(lblLogged);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 101, 445, 189);
		frmHotelReservationSystem.getContentPane().add(scrollPane);
		
		tableRooms = new JTable();
		scrollPane.setViewportView(tableRooms);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(465, 101, 411, 189);
		frmHotelReservationSystem.getContentPane().add(scrollPane_1);
		
		tableCustomers = new JTable();
		scrollPane_1.setViewportView(tableCustomers);

		hotel.getCustomers().add(new Customer("Ahmet","Celik",30,"5552341123","W23DTR31AA"));
		hotel.getCustomers().add(new Customer("Can","Kurt",40,"5077441152","115847WEDAER"));
		hotel.getCustomers().add(new Customer("Gamze","Helin",25,"5513326615","DD115362Q1"));
		Employee e = new Employee("Mehmet","Cakir",35,4250,"Receptionist");
		hotel.getRooms().add(new Room("1",new HashMap<Integer,Customer>()));
		hotel.getRooms().add(new Room("2",new HashMap<Integer,Customer>()));
		hotel.getRooms().add(new Room("3",new HashMap<Integer,Customer>()));
		hotel.getRooms().add(new Room("4",new HashMap<Integer,Customer>()));
		hotel.getRooms().add(new Room("5",new HashMap<Integer,Customer>()));
		lblLogged.setText(e.getName()+" "+e.getSurname()+" Age: "+e.getAge()+" Dep: "+e.getDepartment());
		listRooms();
		listCustomers();
		showRooms();
		showCustomers();
	}
}
