import java.util.ArrayList;

public class Hotel implements IHotel {
    private ArrayList<Room> rooms;
    private ArrayList<Customer> customers;
    public Hotel(ArrayList<Room> rooms) {
        this.rooms = rooms;
        customers = new ArrayList<Customer>();
    }

    @Override
    public ArrayList<Room> getRooms() {
        return rooms;
    }

    @Override
    public void setRooms(ArrayList<Room> rooms) {
        this.rooms = rooms;
    }
    @Override
    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    @Override
    public void setCustomers(ArrayList<Customer> customers) {
        this.customers= customers;
    }

    @Override
    public boolean RentRoom(Customer customer, Room room){
        if (room.IsEmpty()){
            room.getCustomers().put(room.getCustomers().size()+1,customer);
            return true;
        }
        else return false;
    }

    @Override
    public String toString() {
        return "Hotel{" +
                "rooms=" + rooms +
                '}';
    }
}
