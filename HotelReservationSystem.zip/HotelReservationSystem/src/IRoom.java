import java.util.Map;

public interface IRoom {
    String getId();

    void setId(String id);

    Map<Integer, Customer> getCustomers();

    void setCustomers(Map<Integer, Customer> customers);

    boolean IsEmpty();

    @Override
    String toString();
}
