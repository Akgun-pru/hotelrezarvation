public interface IEmployee {
    double getWage();

    void setWage(double wage);

    String getDepartment();

    void setDepartment(String department);

    @Override
    String toString();
}
