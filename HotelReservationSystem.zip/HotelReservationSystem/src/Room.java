import java.util.Map;

public class Room implements IRoom {
    String id;
    private Map<Integer,Customer> customers;

    public Room(String id, Map<Integer, Customer> customers) {
        this.id = id;
        this.customers = customers;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    @Override
    public Map<Integer, Customer> getCustomers() {
        return customers;
    }

    @Override
    public void setCustomers(Map<Integer, Customer> customers) {
        this.customers = customers;
    }
    @Override
    public boolean IsEmpty(){
        return customers.isEmpty();
    }
    @Override
    public String toString() {
        return "Room{" +
                "id='" + id + '\'' +
                ", customers=" + customers +
                '}';
    }
}
